%dw 2.0
output application/json
---
{
	sourceObject: attributes.relativePath,
	fieldNames: attributes.queryParams.fieldNames,
	whereClause: attributes.queryParams.filterClause
}